# Application Specification

## Problem Statement

## Functional Requirements

1. 
2. 
3. 
4. 
5. 
6. 

## Non-functional

1. 
2. 
3. 

## Use Cases

### Use Case 1 Name

#### Stakeholders and Actors

#### Use Case Goal

#### Primary Actor

#### Preconditions

#### Basic Flow

#### Alternative Flows

## Use Case Diagram

![Use Case Diagram](usecase.png)
