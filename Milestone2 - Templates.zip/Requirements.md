# Non-functional Requirements

## Non-functional requirement 1

Explain specifically how you will account for this requirement in your application.

# Use case name

## Actors
1. Actor 1
2. Actor 2

## Use case goal

## Primary Actor

## Preconditions

## Basic flow

## Alternative flows

### Alternative flow 1

### Alternative flow 2
